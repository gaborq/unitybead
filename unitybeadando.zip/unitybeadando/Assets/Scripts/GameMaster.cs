﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GameMaster : MonoBehaviour
{
   
     [SerializeField] private string nextLevel;
    [SerializeField] public Vector3 respawnPoint;

    void OnTriggerEnter2D(Collider2D other){
        if (other.gameObject.tag == "Finish")
{
        transform.position = respawnPoint;
}
    
    if(other.gameObject.tag == "Checkpoint")
       
    {
        respawnPoint = other.transform.position;
    }

    

}
}
